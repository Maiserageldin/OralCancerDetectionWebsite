// import React, { createContext, useState } from "react";

// const ActiveDashboardContext = createContext(null);

// const ActiveDashboardProvider = ({ children }) => {
//   const [activeDashboard, setActiveDashboard] = useState(null);

//   const updateActiveDashboard = (role) => {
//     setActiveDashboard(role);
//   };

//   return (
//     <ActiveDashboardContext.Provider
//       value={{ activeDashboard, updateActiveDashboard }}
//     >
//       {children}
//     </ActiveDashboardContext.Provider>
//   );
// };

// export { ActiveDashboardContext, ActiveDashboardProvider };
