// fontAwesome.js

import { library } from "@fortawesome/fontawesome-svg-core";
import {
  faMapMarkerAlt,
  faPhoneAlt,
  faEnvelope,
} from "@fortawesome/free-solid-svg-icons";

library.add(faMapMarkerAlt, faPhoneAlt, faEnvelope);
